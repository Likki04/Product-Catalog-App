"use client";

import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";

export default function AdminLoginPage() {
  const [form, setForm] = useState({ username: "", email: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.username.trim()) e.username = "Username is required";
    if (!form.email.endsWith("@gmail.com")) e.email = "Must end with @gmail.com";
    if (form.password.length < 8) e.password = "Must be at least 8 characters";
    return e;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    setErrors((prev) => { const n = { ...prev }; delete n[e.target.name]; return n; });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1200));
    setLoading(false);
    setSuccess(true);
  };

  if (success) {
    return (
      <div className="min-h-screen bg-[#0A0A0B] flex items-center justify-center">
        <div className="text-center">
          <p className="font-display text-2xl text-ivory mb-2">Welcome back</p>
          <p className="font-mono text-xs text-ivory/30 tracking-widest uppercase">Redirecting...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0B] flex items-center justify-center px-4">
      <div className="w-full max-w-sm">

        {/* Brand */}
        <div className="mb-10 text-center">
          <h1 className="font-display text-2xl tracking-[0.2em] text-gradient-gold">Likitha's Store</h1>
          <p className="font-mono text-[10px] tracking-[0.3em] uppercase text-ivory/25 mt-1">
            Admin Login
          </p>
        </div>

        <form onSubmit={handleSubmit} noValidate className="space-y-5">

          {/* Username */}
          <div>
            <label className="block text-xs text-ivory/40 mb-1.5">Username</label>
            <input
              type="text"
              name="username"
              value={form.username}
              onChange={handleChange}
              placeholder="Enter username"
              className="input-field"
            />
            {errors.username && (
              <p className="mt-1 text-red-400 text-xs">{errors.username}</p>
            )}
          </div>

          {/* Email */}
          <div>
            <label className="block text-xs text-ivory/40 mb-1.5">Email</label>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder="admin@gmail.com"
              className="input-field"
            />
            {errors.email ? (
              <p className="mt-1 text-red-400 text-xs">{errors.email}</p>
            ) : (
              <p className="mt-1 text-ivory/20 text-xs">Must end with @gmail.com</p>
            )}
          </div>

          {/* Password */}
          <div>
            <label className="block text-xs text-ivory/40 mb-1.5">Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                value={form.password}
                onChange={handleChange}
                placeholder="Min. 8 characters"
                className="input-field pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-ivory/30 hover:text-ivory/60 transition-colors"
              >
                {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
            {errors.password ? (
              <p className="mt-1 text-red-400 text-xs">{errors.password}</p>
            ) : (
              <p className="mt-1 text-ivory/20 text-xs">Minimum 8 characters</p>
            )}
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={loading}
            className="btn-primary w-full text-center mt-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? "Signing in..." : "Sign In"}
          </button>

        </form>
      </div>
    </div>
  );
}
