"use client";

import { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import ProductForm from "@/components/ProductForm";
import { Product } from "@/lib/types";

export default function EditProductPage() {
  const { id } = useParams();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function fetchProduct() {
      try {
        const res = await fetch(`/api/products/${id}`);
        if (!res.ok) throw new Error("Product not found");
        const data = await res.json();
        setProduct(data.data);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load");
      } finally {
        setLoading(false);
      }
    }
    if (id) fetchProduct();
  }, [id]);

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto px-6 py-12">
        <div className="space-y-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-12 shimmer rounded" />
          ))}
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="max-w-3xl mx-auto px-6 py-20 text-center">
        <p className="font-display text-3xl text-ivory/20 mb-6">{error || "Not Found"}</p>
        <Link href="/" className="btn-secondary">← Back to Catalog</Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-6 py-12">
      {/* Back */}
      <Link
        href={`/catalog/${id}`}
        className="inline-flex items-center gap-2 text-ivory/40 hover:text-ivory/70 font-mono text-xs tracking-widest uppercase transition-colors mb-10"
      >
        <ArrowLeft size={12} />
        Back to Product
      </Link>

      {/* Header */}
      <div className="mb-10">
        <p className="font-mono text-xs tracking-[0.3em] text-gold/50 uppercase mb-3">Editing</p>
        <h1 className="font-display text-4xl md:text-5xl text-ivory">{product.name}</h1>
        <div className="mt-4 h-px w-16 bg-gold/40" />
      </div>

      {/* Form */}
      <div className="bg-obsidian-2 border border-white/5 p-8 md:p-10">
        <ProductForm mode="edit" initialData={product} productId={product.id} />
      </div>
    </div>
  );
}
