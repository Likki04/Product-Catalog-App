"use client";

import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowLeft, Edit2, Trash2, Tag, Calendar } from "lucide-react";
import { Product } from "@/lib/types";

export default function ProductDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [deleting, setDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    async function fetchProduct() {
      try {
        const res = await fetch(`/api/products/${id}`);
        if (!res.ok) throw new Error("Product not found");
        const data = await res.json();
        setProduct(data.data);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load product");
      } finally {
        setLoading(false);
      }
    }
    if (id) fetchProduct();
  }, [id]);

  const handleDelete = async () => {
    setDeleting(true);
    try {
      const res = await fetch(`/api/products/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete");
      router.push("/");
    } catch {
      setError("Failed to delete product");
      setDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto px-6 py-12">
        <div className="h-4 w-24 shimmer mb-10 rounded" />
        <div className="grid md:grid-cols-2 gap-12">
          <div className="aspect-square shimmer" />
          <div className="space-y-4">
            <div className="h-6 w-20 shimmer rounded" />
            <div className="h-10 w-3/4 shimmer rounded" />
            <div className="h-4 w-full shimmer rounded" />
            <div className="h-4 w-5/6 shimmer rounded" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="max-w-5xl mx-auto px-6 py-20 text-center">
        <p className="font-display text-4xl text-ivory/20 mb-4">{error || "Not Found"}</p>
        <Link href="/" className="btn-secondary">← Back to Catalog</Link>
      </div>
    );
  }

  const formattedDate = new Date(product.createdAt).toLocaleDateString("en-US", {
    year: "numeric", month: "long", day: "numeric"
  });

  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      {/* Back */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-ivory/40 hover:text-ivory/70 font-mono text-xs tracking-widest uppercase transition-colors mb-10"
        >
          <ArrowLeft size={12} />
          Back to Catalog
        </Link>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-12 lg:gap-20">
        {/* Image */}
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          className="relative"
        >
          <div className="relative aspect-square bg-obsidian-3 overflow-hidden border border-white/5">
            <Image
              src={product.image}
              alt={product.name}
              fill
              className="object-cover"
              priority
            />
          </div>
          {/* Decorative corner */}
          <div className="absolute -bottom-3 -right-3 w-24 h-24 border-r-2 border-b-2 border-gold/20 pointer-events-none" />
          <div className="absolute -top-3 -left-3 w-24 h-24 border-l-2 border-t-2 border-gold/20 pointer-events-none" />
        </motion.div>

        {/* Details */}
        <motion.div
          initial={{ opacity: 0, x: 24 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="flex flex-col"
        >
          {/* Meta */}
          <div className="flex items-center gap-3 mb-5">
            <span className="category-pill border-gold/30 text-gold/70 font-mono">
              <Tag size={10} className="inline mr-1" />
              {product.category}
            </span>
            <span className="font-mono text-xs text-ivory/25">
              #{String(product.id).padStart(3, "0")}
            </span>
          </div>

          {/* Name */}
          <h1 className="font-display text-3xl md:text-4xl text-ivory leading-tight mb-4">
            {product.name}
          </h1>

          {/* Price */}
          <div className="mb-6">
            <p className="font-mono text-xs tracking-widest uppercase text-ivory/30 mb-1">Price</p>
            <p className="font-display text-4xl text-gradient-gold">
              ${product.price.toLocaleString("en-US", { minimumFractionDigits: 0 })}
            </p>
          </div>

          {/* Divider */}
          <div className="h-px bg-gradient-to-r from-gold/20 to-transparent mb-6" />

          {/* Description */}
          <p className="text-ivory/60 font-body leading-relaxed text-sm mb-8">
            {product.description}
          </p>

          {/* Date */}
          <div className="flex items-center gap-2 text-ivory/25 font-mono text-xs mb-8">
            <Calendar size={11} />
            Added {formattedDate}
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3 mt-auto">
            <Link href={`/catalog/${product.id}/edit`} className="btn-primary flex-1 text-center flex items-center justify-center gap-2">
              <Edit2 size={14} />
              Edit Product
            </Link>
            {!showDeleteConfirm ? (
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="btn-danger flex-1 flex items-center justify-center gap-2"
              >
                <Trash2 size={14} />
                Delete
              </button>
            ) : (
              <div className="flex-1 border border-red-700/50 bg-red-950/30 p-3 text-center">
                <p className="text-red-400 font-mono text-xs mb-3">Confirm delete?</p>
                <div className="flex gap-2">
                  <button
                    onClick={handleDelete}
                    disabled={deleting}
                    className="flex-1 bg-red-900/50 text-red-300 font-mono text-xs uppercase tracking-wider py-2 hover:bg-red-900 transition-colors"
                  >
                    {deleting ? "Deleting..." : "Yes, delete"}
                  </button>
                  <button
                    onClick={() => setShowDeleteConfirm(false)}
                    className="flex-1 bg-obsidian-3 text-ivory/50 font-mono text-xs uppercase tracking-wider py-2 hover:text-ivory transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
