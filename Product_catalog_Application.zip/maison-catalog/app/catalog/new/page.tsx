import { motion } from "framer-motion";
import ProductForm from "@/components/ProductForm";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export default function NewProductPage() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-12">
      {/* Back nav */}
      <Link
        href="/"
        className="inline-flex items-center gap-2 text-ivory/40 hover:text-ivory/70 font-mono text-xs tracking-widest uppercase transition-colors mb-10"
      >
        <ArrowLeft size={12} />
        Back to Catalog
      </Link>

      {/* Header */}
      <div className="mb-10">
        <p className="font-mono text-xs tracking-[0.3em] text-gold/50 uppercase mb-3">New Entry</p>
        <h1 className="font-display text-4xl md:text-5xl text-ivory">Add Product</h1>
        <div className="mt-4 h-px w-16 bg-gold/40" />
      </div>

      {/* Form wrapper */}
      <div className="bg-obsidian-2 border border-white/5 p-8 md:p-10">
        <ProductForm mode="create" />
      </div>
    </div>
  );
}
