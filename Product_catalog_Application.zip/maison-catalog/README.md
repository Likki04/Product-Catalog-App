# MAISON — Product Catalog Management System

A full-stack Next.js 14 application with TypeScript featuring a luxury editorial design aesthetic.

---

## 📁 Folder Structure

```
product-catalog/
├── app/
│   ├── api/
│   │   └── products/
│   │       ├── route.ts           # GET /api/products, POST /api/products
│   │       └── [id]/
│   │           └── route.ts       # GET/PUT/DELETE /api/products/:id
│   ├── catalog/
│   │   ├── new/
│   │   │   └── page.tsx           # Add product page
│   │   └── [id]/
│   │       ├── page.tsx           # Product detail page
│   │       └── edit/
│   │           └── page.tsx       # Edit product page
│   ├── globals.css                # Global styles + Tailwind
│   ├── layout.tsx                 # Root layout with fonts & Navbar
│   └── page.tsx                   # Home page — product catalog grid
├── components/
│   ├── Navbar.tsx                 # Sticky navbar
│   ├── ProductCard.tsx            # Card with hover animations
│   ├── ProductForm.tsx            # Reusable create/edit form
│   └── LoadingSkeleton.tsx        # Shimmer loading states
├── lib/
│   ├── db.ts                      # In-memory JSON-style database
│   └── types.ts                   # Shared TypeScript interfaces
├── next.config.js
├── tailwind.config.ts
├── tsconfig.json
├── postcss.config.js
└── package.json
```

---

## 🛠 Tech Stack

| Layer     | Technology                                          |
|-----------|-----------------------------------------------------|
| Framework | Next.js 14 (App Router)                            |
| Language  | TypeScript                                          |
| Styling   | Tailwind CSS                                        |
| Animation | Framer Motion                                       |
| Icons     | Lucide React                                        |
| Fonts     | Playfair Display, DM Sans, DM Mono (Google Fonts)  |
| Database  | In-memory JSON array (`/lib/db.ts`)                |

---

## 🚀 Installation & Setup

### 1. Navigate into the project

```bash
cd product-catalog
```

### 2. Install dependencies

```bash
npm install
```

### 3. Run the development server

```bash
npm run dev
```

### 4. Open in browser

```
http://localhost:3000
```

---

## 🔌 API Endpoints

| Method | Endpoint              | Description           |
|--------|-----------------------|-----------------------|
| GET    | /api/products         | Get all products      |
| POST   | /api/products         | Create a product      |
| GET    | /api/products/:id     | Get product by ID     |
| PUT    | /api/products/:id     | Update product by ID  |
| DELETE | /api/products/:id     | Delete product by ID  |

### Product Schema

```typescript
{
  id: number;
  name: string;
  price: number;
  category: string;
  image: string;       // URL to image
  description: string;
  createdAt: string;   // ISO date string
}
```

---

## 📱 Pages

| Route              | Description                          |
|--------------------|--------------------------------------|
| `/`                | Home — browsable product catalog grid |
| `/catalog/new`     | Add a new product                    |
| `/catalog/:id`     | Product detail view                  |
| `/catalog/:id/edit`| Edit existing product                |

---

## ✨ Features

- **8 seeded products** with real Unsplash imagery
- **Search** products by name/description
- **Filter** by category
- **Full CRUD** operations via REST API
- **Shimmer loading** skeletons
- **Framer Motion** entrance animations with stagger
- **Image preview** when adding/editing products
- **Delete confirmation** UI to prevent accidents
- **Fully responsive** — mobile, tablet, desktop
- **Luxury editorial design** — Obsidian/gold palette, serif display type
