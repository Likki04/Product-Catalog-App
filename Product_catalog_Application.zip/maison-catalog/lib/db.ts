export interface Product {
  id: number;
  name: string;
  price: number;
  category: string;
  image: string;
  description: string;
  createdAt: string;
}

let nextId = 9;

export const products: Product[] = [
  {
    id: 1,
    name: "Obsidian Chronograph",
    price: 4850,
    category: "Watches",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&q=80",
    description: "A masterpiece of horology crafted from aerospace-grade obsidian composite. The dial features hand-applied indices and a sapphire crystal with triple AR coating. Water resistant to 300m.",
    createdAt: "2024-01-10T09:00:00Z",
  },
  {
    id: 2,
    name: "Verdant Ceramic Vessel",
    price: 320,
    category: "Home & Living",
    image: "https://images.unsplash.com/photo-1612196808214-b7e239e5f6b9?w=800&q=80",
    description: "Hand-thrown on a kick wheel from stoneware clay sourced in the Loire Valley. Each piece is unique, with organic ash-glaze finish that shifts from moss to amber in different lighting conditions.",
    createdAt: "2024-01-12T10:30:00Z",
  },
  {
    id: 3,
    name: "Noir Leather Folio",
    price: 895,
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&q=80",
    description: "Full-grain vegetable-tanned leather aged in small batches. Interior features silk lining from Como, 12 card slots, and a hidden magnetic closure. Develops a rich patina with use.",
    createdAt: "2024-01-15T08:00:00Z",
  },
  {
    id: 4,
    name: "Aurora Pendant Lamp",
    price: 1240,
    category: "Lighting",
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800&q=80",
    description: "Mouth-blown borosilicate glass with 24-karat gold leaf inclusions. Each lamp takes 8 hours to produce. Includes hand-braided textile cord in three colorways and a dimmer-compatible LED module.",
    createdAt: "2024-01-18T11:00:00Z",
  },
  {
    id: 5,
    name: "Alpine Merino Coat",
    price: 2100,
    category: "Apparel",
    image: "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=800&q=80",
    description: "Woven from 17.5-micron merino sourced from a single estate in Patagonia. Double-breasted silhouette with horn buttons. Fully canvassed construction. Unlined for a fluid drape.",
    createdAt: "2024-01-20T14:00:00Z",
  },
  {
    id: 6,
    name: "Hinoki Bath Ritual Set",
    price: 480,
    category: "Wellness",
    image: "https://images.unsplash.com/photo-1600189261867-30e5ffe7b8da?w=800&q=80",
    description: "Curated collection of Japanese hinoki wood accessories: bath stool, soap dish, and toothbrush holder. Naturally antibacterial with a subtle forest fragrance that deepens with steam exposure.",
    createdAt: "2024-01-22T09:30:00Z",
  },
  {
    id: 7,
    name: "Onyx Espresso Machine",
    price: 3200,
    category: "Kitchen",
    image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800&q=80",
    description: "E61 grouphead with PID temperature control to ±0.1°C. 58mm commercial portafilter. Dual boiler system for simultaneous brewing and steaming. Powder-coated cast iron body in matte black.",
    createdAt: "2024-01-25T10:00:00Z",
  },
  {
    id: 8,
    name: "Cartography Print Series",
    price: 650,
    category: "Art",
    image: "https://images.unsplash.com/photo-1553356084-58ef4a67b2a7?w=800&q=80",
    description: "Set of three archival giclée prints on 300gsm cotton rag paper. Antique cartographic illustrations of imaginary continents, hand-touched with 22-karat gold leaf accents. Edition of 50.",
    createdAt: "2024-01-28T13:00:00Z",
  },
];

export function getAllProducts(): Product[] {
  return [...products].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export function getProductById(id: number): Product | undefined {
  return products.find((p) => p.id === id);
}

export function createProduct(data: Omit<Product, "id" | "createdAt">): Product {
  const product: Product = {
    ...data,
    id: nextId++,
    createdAt: new Date().toISOString(),
  };
  products.push(product);
  return product;
}

export function updateProduct(id: number, data: Partial<Omit<Product, "id" | "createdAt">>): Product | null {
  const index = products.findIndex((p) => p.id === id);
  if (index === -1) return null;
  products[index] = { ...products[index], ...data };
  return products[index];
}

export function deleteProduct(id: number): boolean {
  const index = products.findIndex((p) => p.id === id);
  if (index === -1) return false;
  products.splice(index, 1);
  return true;
}
