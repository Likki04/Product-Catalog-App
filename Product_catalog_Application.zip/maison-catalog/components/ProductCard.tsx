"use client";

import Link from "next/link";
import Image from "next/image";
import { Product } from "@/lib/types";

interface ProductCardProps {
  product: Product;
  index: number;
}

export default function ProductCard({ product }: ProductCardProps) {
  return (
    <Link href={`/catalog/${product.id}`} className="group block border border-white/8 hover:border-white/16 transition-colors bg-obsidian-2">
      {/* Image */}
      <div className="relative aspect-[4/3] bg-obsidian-3 overflow-hidden">
        <Image
          src={product.image}
          alt={product.name}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-500"
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
        />
      </div>

      {/* Info */}
      <div className="p-4">
        <p className="text-xs text-ivory/30 mb-1">{product.category}</p>
        <h3 className="text-sm font-body text-ivory mb-2 line-clamp-1">{product.name}</h3>
        <p className="text-xs text-ivory/40 line-clamp-2 mb-3">{product.description}</p>
        <p className="text-sm font-medium text-gold">
          ${product.price.toLocaleString("en-US", { minimumFractionDigits: 0 })}
        </p>
      </div>
    </Link>
  );
}
