"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export default function Navbar() {
  const pathname = usePathname();

  const links = [
    { href: "/", label: "Catalog" },
    { href: "/catalog/new", label: "Add Product" },
    { href: "/admin/login", label: "Admin" },
  ];

  return (
    <nav className="border-b border-white/8 bg-obsidian px-6 py-4 flex items-center justify-between">
      <Link href="/" className="text-ivory font-body font-medium text-sm">
        Likitha&apos;s Store
      </Link>
      <div className="flex items-center gap-6">
        {links.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className={`text-xs font-body transition-colors ${
              pathname === link.href ? "text-gold" : "text-ivory/40 hover:text-ivory"
            }`}
          >
            {link.label}
          </Link>
        ))}
      </div>
    </nav>
  );
}
