export default function LoadingSkeleton() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="bg-obsidian-2 border border-white/5 overflow-hidden">
          <div className="aspect-[4/3] shimmer" />
          <div className="p-5 space-y-3">
            <div className="h-5 w-20 shimmer rounded" />
            <div className="h-6 w-3/4 shimmer rounded" />
            <div className="h-4 w-full shimmer rounded" />
            <div className="h-4 w-5/6 shimmer rounded" />
            <div className="h-px bg-white/5 my-2" />
            <div className="h-7 w-24 shimmer rounded" />
          </div>
        </div>
      ))}
    </div>
  );
}
