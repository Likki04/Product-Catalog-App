"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Product } from "@/lib/types";

interface ProductFormProps {
  initialData?: Partial<Product>;
  mode: "create" | "edit";
  productId?: number;
}

const CATEGORIES = [
  "Watches", "Home & Living", "Accessories", "Lighting",
  "Apparel", "Wellness", "Kitchen", "Art", "Electronics", "Books", "Other",
];

export default function ProductForm({ initialData, mode, productId }: ProductFormProps) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [form, setForm] = useState({
    name: initialData?.name || "",
    price: initialData?.price?.toString() || "",
    category: initialData?.category || "",
    image: initialData?.image || "",
    description: initialData?.description || "",
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const url = mode === "create" ? "/api/products" : `/api/products/${productId}`;
      const method = mode === "create" ? "POST" : "PUT";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Something went wrong");

      if (mode === "create") {
        router.push(`/catalog/${data.data.id}`);
      } else {
        router.push(`/catalog/${productId}`);
      }
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save product");
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.form
      onSubmit={handleSubmit}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      {error && (
        <div className="border border-red-800/50 bg-red-950/30 text-red-400 text-sm font-mono px-4 py-3">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Name */}
        <div className="md:col-span-2">
          <label className="block font-mono text-xs tracking-widest uppercase text-ivory/40 mb-2">
            Product Name *
          </label>
          <input
            type="text"
            name="name"
            value={form.name}
            onChange={handleChange}
            required
            placeholder="e.g. Obsidian Chronograph"
            className="input-field"
          />
        </div>

        {/* Price */}
        <div>
          <label className="block font-mono text-xs tracking-widest uppercase text-ivory/40 mb-2">
            Price (USD) *
          </label>
          <input
            type="number"
            name="price"
            value={form.price}
            onChange={handleChange}
            required
            min="0"
            step="0.01"
            placeholder="0.00"
            className="input-field"
          />
        </div>

        {/* Category */}
        <div>
          <label className="block font-mono text-xs tracking-widest uppercase text-ivory/40 mb-2">
            Category *
          </label>
          <select
            name="category"
            value={form.category}
            onChange={handleChange}
            required
            className="input-field"
          >
            <option value="" disabled>Select category</option>
            {CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>

        {/* Image URL */}
        <div className="md:col-span-2">
          <label className="block font-mono text-xs tracking-widest uppercase text-ivory/40 mb-2">
            Image URL
          </label>
          <input
            type="url"
            name="image"
            value={form.image}
            onChange={handleChange}
            placeholder="https://images.unsplash.com/... or paste any image URL"
            className="input-field"
          />
          <p className="mt-1.5 text-ivory/25 text-xs font-mono">
            Paste any image URL — Unsplash, Google Images (right-click → Copy image address), etc.
          </p>
        </div>

        {/* Description */}
        <div className="md:col-span-2">
          <label className="block font-mono text-xs tracking-widest uppercase text-ivory/40 mb-2">
            Description *
          </label>
          <textarea
            name="description"
            value={form.description}
            onChange={handleChange}
            required
            rows={5}
            placeholder="Describe this product in detail..."
            className="input-field resize-none"
          />
        </div>
      </div>

      {/* Preview image if URL provided */}
      {form.image && (
        <div className="border border-white/5 p-4">
          <p className="font-mono text-xs tracking-widest uppercase text-ivory/30 mb-3">Image Preview</p>
          <img
            src={form.image}
            alt="Preview"
            className="h-40 w-full object-cover"
            onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
          />
        </div>
      )}

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-4 pt-2">
        <button type="submit" disabled={loading} className="btn-primary flex-1 text-center">
          {loading ? (
            <span className="inline-flex items-center gap-2">
              <span className="w-3 h-3 border border-obsidian/50 border-t-obsidian rounded-full animate-spin" />
              {mode === "create" ? "Creating..." : "Saving..."}
            </span>
          ) : (
            mode === "create" ? "Create Product" : "Save Changes"
          )}
        </button>
        <button
          type="button"
          onClick={() => router.back()}
          className="btn-secondary flex-1 text-center"
        >
          Cancel
        </button>
      </div>
    </motion.form>
  );
}
